int printf(char const *format, ...);

int main()
{
  printf("hello, world!\n");
  printf("yo");
  return 0;
}